# 财务分析：CNO 2025 年第一季度保险利益费用 — 题包

## 任务与交付物

Results、Analysis、Summary 三张必需表，答案工作簿。

`solution/golden/answer.xlsx`、`solution/golden_output/answer.xlsx`、输入、评分器及离线正负例。

## 当前评分

版本标签：评分器 v2（2026-10-26）；此日期为评分版本标签，不是本次整理的执行日期。

正项按正确度计入，负项按违规程度扣除；负项不进入分母。令 `pooled = clip((Σ(w×正确度) − Σ(|负权重|×违规程度)) / 34, 0, 1)`，`reward = round(min(pooled, 所有已触发规则的上限), 6)`；无触发规则时上限为 1，通过线为 0.70。

- Results、Analysis 或 Summary 缺失或错名：gate = 0。
- 必需前置表头不符，或来源/支持格空白或纯数字、单位不符、额外业务记录：对应 cap = 0.69。允许合法后附列、空白样式列和自由支持表。
- 行序、重复记录、数值、精度及其他负项按现有判据处理；精度为显示或存值合规，数值容差另算。具体项、权重、舍入和文字/程序分工见 [评分口径](validation/scoring_policy.md)。

| 答卷 | 当前记录 | 裁判状态 |
|---|---:|---|
| 金标 | 程序分 1.000000；混合总分 1.000000 | Sonnet有效判定5/5；`PASS` |
| GPT-5.6-SOL | 0.205882 | 本轮有效重判；答卷未改动 |
| Claude Opus 4.8 | 0.000000 | 沿用已保存判定；未重新裁判 |
| Qwen3.8 Max | 0.000000 | 沿用已保存判定；未重新裁判 |

金标当前分只使用本轮有效判定，Sonnet golden_r1作为代表。旧暂定分、被替换记录及无效尝试留在 `history/`，不参与本轮一致性统计。未进行八次独立求解，不提供 pass@8。

## 离线复现

需要 Python 3.11+ 和已安装的 openpyxl；不需要服务凭据。将配套轨迹报告与题包并列放置，用于核对已保存的分数与判定状态。

在本目录执行：

```sh
python3 -B validation/run_regression.py
python3 -B validation/validate_paths.py
```

回归涵盖 60 个负例、12 个正例，以及池化、候选文件访问校验和已保存报告；只做离线验证，不启动求解或裁判，不修改交付文件。配套目录不在默认位置时，`run_regression.py --trajectory 轨迹报告根目录`。

历次变更与原交付说明见 [历史变更记录](history/CHANGELOG.md)，归档分组见 [历史目录说明](history/README.md)。

## 裁判更换（2026-10-26）

LLM 裁判从 qwen3.7-plus 换成 claude-sonnet-5-5。qwen 常常没打开答卷就给出判定；这次三道题共 16 次 Sonnet 评分，每次都打开了工作簿，并在理由里引用了候选单元格。判据、权重、程序规则和所有答卷都没有改。

参考答案用 Sonnet 评了 5 次，5 次都有效，总分都是 1.0。总分和每条判据的标准差都是 0，低于 0.05 的要求。上一版只有 3 次有效。`judge_runs/golden_r1` 到 `golden_r5` 是这 5 次的记录，`golden/` 取第 1 次。

GPT-5.6-SOL 的答卷用 Sonnet 重新评了一次，仍是 0.205882。另外两个模型的答卷没有重新评分：程序分都是 0，三条 LLM 判据只会扣分，总分最低截到 0，换哪个裁判都是 0。这两份保留原来的评分记录。

运行评分时请显式设置 `JUDGE_MODEL`。`task.toml` 已把默认值设为 claude-sonnet-5-5；直接运行 `tests/test.sh` 又不设这个变量时，平台模板会退回 qwen3.7-plus。

旧的 qwen 评分记录收在 `history/judge_sonnet_20261026/previous/`。
